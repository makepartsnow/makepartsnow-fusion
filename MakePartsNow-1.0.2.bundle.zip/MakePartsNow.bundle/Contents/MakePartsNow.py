"""MakePartsNow add-in for Autodesk Fusion: entry points Fusion calls.

``run`` only registers the commands, the MAKE PARTS NOW toolbar panel and the
buttons (Autodesk asks for under 5 ms at startup); the palette and everything
else load when the button is first clicked. ``stop`` removes everything the
add-in added. Neither lets an exception escape into Fusion.
"""

import traceback

import adsk.core

from .makepartsnow_fusion import palette_ui


def _show(text: str) -> None:
    try:
        adsk.core.Application.get().userInterface.messageBox(text, "Make Parts Now")
    except Exception:  # noqa: BLE001 - nothing more can be done
        pass


def run(context):
    try:
        palette_ui.start()
    except Exception:  # noqa: BLE001 - never let a startup error reach Fusion
        _show("MakePartsNow could not start.\n\n" + traceback.format_exc())


def stop(context):
    try:
        palette_ui.stop()
    except Exception:  # noqa: BLE001
        _show("MakePartsNow could not stop cleanly.\n\n" + traceback.format_exc())
