/* Make Parts Now palette: draws the screens from the view model Python sends.

   Python owns the state. The page sends user actions with adsk.fusionSendData(action, json)
   and redraws from every "state" message: the Promise's answer (HTMLEventArgs.returnData)
   and pushes via palette.sendInfoToHTML, which arrive at window.fusionJavaScriptHandler.
   A "seq" number drops an older state that arrives after a newer one.

   Everything shown is escaped (h()). Links never navigate the palette: clicks on
   [data-link] go to Python, which opens them in the system browser. Nothing is fetched. */
(function () {
  "use strict";

  var state = null;
  var ui = { menu: null, menuFocus: null, confirmDelete: false, copied: false };
  var toastTimer = null;
  var zipTimer = null;
  var main = document.getElementById("main");
  var actionbar = document.getElementById("actionbar");
  var stepsEl = document.getElementById("steps");
  var toastEl = document.getElementById("toast");

  // ------------------------------------------------------------- bridge

  function send(action, data) {
    var payload = JSON.stringify(data || {});
    var adsk = window.adsk;
    if (!adsk || typeof adsk.fusionSendData !== "function") {
      return;
    }
    var answer;
    try {
      answer = adsk.fusionSendData(action, payload);
    } catch (e) {
      return;
    }
    if (answer && typeof answer.then === "function") {
      answer.then(applyAnswer, function () {});
    } else {
      applyAnswer(answer);
    }
  }

  function applyAnswer(text) {
    if (!text || typeof text !== "string" || text.charAt(0) !== "{") {
      return;
    }
    try {
      applyState(JSON.parse(text));
    } catch (e) { /* not a state */ }
  }

  // Python -> page (Palette.sendInfoToHTML). Must return a non-empty string.
  window.fusionJavaScriptHandler = {
    handle: function (action, data) {
      try {
        var payload = typeof data === "string" && data ? JSON.parse(data) : (data || {});
        if (action === "state") {
          applyState(payload);
        } else if (action === "progress") {
          applyProgress(payload);
        } else if (action === "toast") {
          showToast(payload.text, payload.kind);
        }
      } catch (e) {
        return "ERROR";
      }
      return "OK";
    }
  };

  // While a quote runs, check in every 2 s: Python runs any step whose idle event Fusion didn't deliver, and the
  // answer carries the latest state if a pushed update was lost.
  var heartbeatTimer = null;
  function heartbeat(on) {
    if (on && !heartbeatTimer) {
      heartbeatTimer = setInterval(function () { send("ping", {}); }, 2000);
    } else if (!on && heartbeatTimer) {
      clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
  }

  // Fusion injects window.adsk after the page loads; wait for it, then say hello.
  function waitForFusion() {
    var tries = 0;
    var timer = setInterval(function () {
      tries += 1;
      if (window.adsk && typeof window.adsk.fusionSendData === "function") {
        clearInterval(timer);
        send("ready", {});
      } else if (tries > 600) {
        clearInterval(timer);
      }
    }, 50);
  }

  // ------------------------------------------------------------ helpers

  function h(value) {
    return String(value === null || value === undefined ? "" : value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function safeColor(hex) {
    return /^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/.test(hex || "") ? hex : "#cccccc";
  }

  var ICONS = {
    check: '<path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
    x: '<path d="M4 4l8 8M12 4l-8 8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    warn: '<path d="M8 1.8l6.6 11.7H1.4z" fill="#f2b64a" stroke="#b07316" stroke-width="1" stroke-linejoin="round"/><path d="M8 6v3.4" stroke="#5b3c0d" stroke-width="1.6" stroke-linecap="round"/><circle cx="8" cy="11.6" r=".95" fill="#5b3c0d"/>',
    info: '<circle cx="8" cy="8" r="6.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M8 7.2v4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="8" cy="4.9" r=".95" fill="currentColor"/>',
    cube: '<path d="M8 1.6l5.6 3.1v6.6L8 14.4l-5.6-3.1V4.7z M2.4 4.7L8 7.8l5.6-3.1 M8 7.8v6.6" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>',
    caret: '<path d="M4 6l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
    plus: '<path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    click: '<path d="M6 2.5v2M2.5 6h2M3.4 3.4l1.4 1.4M9.2 3.4L7.8 4.8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M6.6 6.6l7.6 3-3.2 1.2-1.2 3.2z" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linejoin="round"/>',
    truck: '<path d="M1.5 4h8v6.5h-8zM9.5 6.5h2.8l2.2 2.3v1.7h-5" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><circle cx="4.5" cy="11.5" r="1.4" fill="#fff" stroke="currentColor" stroke-width="1.3"/><circle cx="11.5" cy="11.5" r="1.4" fill="#fff" stroke="currentColor" stroke-width="1.3"/>',
    tag: '<path d="M2 2.5h5.3l6.7 6.7-4.8 4.8L2.5 7.3z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><circle cx="5.2" cy="5.6" r="1.1" fill="currentColor"/>',
    ext: '<path d="M9 2.5h4.5V7M13.5 2.5L7.5 8.5M6 3.5H3v9.5h9.5v-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>',
    trash: '<path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.6 8.5h5.8l.6-8.5" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>',
    pause: '<rect x="4" y="3" width="2.6" height="10" rx=".8" fill="currentColor"/><rect x="9.4" y="3" width="2.6" height="10" rx=".8" fill="currentColor"/>',
    offline: '<path d="M1.5 6.2a9.5 9.5 0 0113 0M3.8 8.6a6.2 6.2 0 018.4 0M6.1 11a3 3 0 013.8 0" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M2 2l12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    clock: '<circle cx="8" cy="8" r="6.3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M8 4.5V8l2.4 1.6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    download: '<path d="M8 2v8M4.8 7l3.2 3.2L11.2 7M2.5 13.5h11" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
    alert: '<circle cx="8" cy="8" r="6.3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M8 4.6v4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><circle cx="8" cy="11.2" r="1" fill="currentColor"/>',
    lock: '<rect x="3" y="7" width="10" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M5.3 7V5a2.7 2.7 0 015.4 0v2" fill="none" stroke="currentColor" stroke-width="1.4"/>'
  };

  function icon(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 16 16" aria-hidden="true" focusable="false">' + ICONS[name] + "</svg>";
  }

  function materialById(id) {
    var list = (state && state.materials) || [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) { return list[i]; }
    }
    return list[0] || { id: id, name: id, short: id, process: "", process_label: "", finishes: [] };
  }

  function link(url, text, cls) {
    return '<a href="' + h(url) + '" data-link="' + h(url) + '"' + (cls ? ' class="' + cls + '"' : "") + ">" + text + "</a>";
  }

  // ------------------------------------------------------------- render

  function applyState(next) {
    if (!next || typeof next !== "object" || typeof next.seq !== "number") { return; }
    if (state && next.seq < state.seq) { return; }
    var screenChanged = !state || state.screen !== next.screen;
    state = next;
    heartbeat(state.screen === "working");
    if (screenChanged) {
      ui.menu = null;
      ui.confirmDelete = false;
    }
    if (!state.uploaded_count) { ui.confirmDelete = false; }
    render(screenChanged);
  }

  function applyProgress(progress) {
    if (!state || state.screen !== "working") { return; }
    state.progress = progress;
    var status = document.getElementById("status");
    if (status && !document.getElementById("phases-" + (progress.phase || ""))) {
      render(false);
      return;
    }
    if (status) { status.textContent = progress.text || ""; }
  }

  function render(screenChanged) {
    var focus = captureFocus();
    var scroll = main.scrollTop;
    document.getElementById("subline").textContent = state.subline || "";
    var badge = document.getElementById("test-badge");
    badge.hidden = !state.test;
    if (state.test) { badge.title = "Quoting against " + state.test.base_url; }
    renderSteps();
    var view = SCREENS[state.screen] || SCREENS.parts;
    var out = view();
    main.innerHTML = out.body + legal();
    actionbar.innerHTML = out.actions || "";
    if (screenChanged) {
      main.scrollTop = 0;
      if (!restoreFocus(focus)) { main.focus({ preventScroll: true }); }
    } else {
      main.scrollTop = scroll;
      restoreFocus(focus);
    }
    if (ui.menu && ui.menuFocus) {
      var item = document.querySelector('.menu [data-material="' + ui.menuFocus + '"]');
      if (item) { item.focus(); }
      ui.menuFocus = null;
    }
  }

  function captureFocus() {
    var el = document.activeElement;
    if (!el || !el.getAttribute) { return null; }
    var key = el.getAttribute("data-focus");
    if (!key) { return null; }
    var info = { key: key, value: null, start: null };
    if (el.tagName === "INPUT" && el.type !== "checkbox") {
      info.value = el.value;
      try { info.start = el.selectionStart; } catch (e) { info.start = null; }
    }
    return info;
  }

  function restoreFocus(info) {
    if (!info) { return false; }
    var el = document.querySelector('[data-focus="' + info.key + '"]');
    if (!el) { return false; }
    if (info.value !== null) { el.value = info.value; }
    el.focus({ preventScroll: true });
    if (info.start !== null && el.setSelectionRange) {
      try { el.setSelectionRange(info.start, info.start); } catch (e) { /* number inputs */ }
    }
    return true;
  }

  function renderSteps() {
    var current = { parts: 1, working: 1, error: 1, quote: 2, ordered: 3 }[state.screen];
    if (state.screen === "consent" || !current) {
      stepsEl.hidden = true;
      return;
    }
    if (state.screen === "working" && state.progress && state.progress.phase && state.progress.phase !== "export") { current = 2; }
    var names = ["Parts", "Quote", "Order"];
    var html = "";
    for (var i = 0; i < 3; i++) {
      var n = i + 1;
      var cls = n < current ? "is-done" : (n === current ? "is-active" : "");
      if (i > 0) { html += '<span class="step-bar' + (n <= current ? " is-done" : "") + '" aria-hidden="true"></span>'; }
      html += '<span class="step ' + cls + '"' + (n === current ? ' aria-current="step"' : "") + ">" +
        '<span class="step-dot" aria-hidden="true">' + (n < current ? icon("check", 12) : n) + "</span>" +
        '<span class="step-label">' + names[i] + "</span></span>";
    }
    stepsEl.innerHTML = html;
    stepsEl.hidden = false;
  }

  function legal() {
    var l = state.links || {};
    return '<footer class="legal">' +
      '<nav aria-label="Make Parts Now links">' + link(l.help, "Help") + '<span aria-hidden="true">&middot;</span>' +
      link(l.privacy, "Privacy") + '<span aria-hidden="true">&middot;</span>' + link(l.terms, "Terms") + "</nav>" +
      "<p>" + h(state.not_affiliated) + "</p>" +
      '<p class="ver">Add-in ' + h(state.version) + "</p></footer>";
  }

  function notice(kind, text) {
    var ic = kind === "error" ? "alert" : (kind === "info" ? "info" : (kind === "ok" ? "check" : "warn"));
    return '<div class="notice is-' + kind + '" role="' + (kind === "error" ? "alert" : "status") + '">' + icon(ic, 15) + "<span>" + h(text) + "</span></div>";
  }

  // ------------------------------------------------------------ screens

  var SCREENS = {};

  SCREENS.consent = function () {
    var c = state.consent || { sections: [], links: [] };
    var body = '<section class="card consent" aria-labelledby="consent-title">' +
      '<span class="pill">' + icon("check", 12) + "No account needed</span>" +
      '<h1 id="consent-title">' + h(c.title) + "</h1>" +
      '<p class="intro">' + h(c.intro) + "</p>";
    (c.sections || []).forEach(function (s) {
      body += "<h2>" + h(s.heading) + "</h2><ul>";
      (s.items || []).forEach(function (item) { body += "<li>" + h(item) + "</li>"; });
      body += "</ul>";
    });
    body += '<p class="links" style="margin:12px 0 0">' + (c.links || []).map(function (l) { return link(l.url, h(l.label)); }).join(' <span aria-hidden="true">&middot;</span> ') + "</p></section>";
    body += '<div class="card"><label class="optin"><input type="checkbox" id="telemetry" data-focus="telemetry">' +
      "<span><b>" + h(c.telemetry_label) + "</b><span>" + h(c.telemetry_hint) + "</span></span></label></div>";
    var actions = '<button class="btn btn-primary btn-lg" data-action="accept" data-focus="accept">Accept and continue</button>' +
      '<p class="fine">Nothing is uploaded until you click Get instant quote.</p>';
    return { body: body, actions: actions };
  };

  SCREENS.parts = function () {
    var parts = state.parts || [];
    var body = "";
    if (!parts.length) {
      body += '<section class="empty" aria-labelledby="empty-title">' +
        '<div class="empty-icon">' + icon("click", 28) + "</div>" +
        '<h2 id="empty-title">Click components or bodies in your design to add them</h2>' +
        "<p>Or select them first, then click Add selected. Up to " + h(state.max_parts) + " parts per quote.</p>" +
        '<button class="btn" data-action="add_selected" data-focus="add-empty">' + icon("plus", 14) + "Add selected</button></section>" +
        '<ul class="perks">' +
        "<li>" + icon("check", 14) + "No account needed, no order minimum</li>" +
        "<li>" + icon("check", 14) + "SLS nylon and FDM plastics, made in-house in the US</li>" +
        "<li>" + icon("check", 14) + "Instant price, ship date and printability checks</li></ul>";
    } else {
      body += '<div class="section-head"><h2 class="section-title">Parts<span class="count">' + parts.length + " of " + h(state.max_parts) + "</span></h2>" +
        '<button class="btn btn-sm" data-action="add_selected" data-focus="add">' + icon("plus", 12) + "Add selected</button></div>";
    }
    (state.notices || []).forEach(function (text) { body += notice("warn", text); });
    parts.forEach(function (p) { body += partCard(p); });
    if (parts.length) {
      var zipBad = state.form_error && /zip/i.test(state.form_error);
      body += '<div class="card zip-row"><label for="zip">Ship to ZIP code<span class="hint">US addresses only</span></label>' +
        '<input class="input" id="zip" data-focus="zip" inputmode="numeric" autocomplete="postal-code" maxlength="10" placeholder="e.g. 90210" value="' + h(state.zip) + '"' +
        (zipBad ? ' aria-invalid="true" aria-describedby="form-error"' : "") + "></div>";
    }
    if (state.form_error) {
      body += '<div id="form-error">' + notice("error", state.form_error) + "</div>";
    }
    var actions = '<button class="btn btn-primary btn-lg" data-action="get_quote" data-focus="get-quote"' + (state.can_quote ? "" : " disabled") + ">Get instant quote</button>" +
      '<p class="fine">No account needed &middot; No order minimum</p>';
    return { body: body, actions: actions };
  };

  function partCard(p) {
    var m = materialById(p.material);
    var open = ui.menu === p.key;
    var finishName = "";
    var swatches = (m.finishes || []).map(function (f) {
      var sel = f.id === p.finish;
      if (sel) { finishName = f.name; }
      return '<button class="swatch' + (sel ? " is-selected" : "") + '" style="background:' + safeColor(f.hex) + '" role="radio" aria-checked="' + sel + '"' +
        ' aria-label="' + h(f.name) + '" title="' + h(f.name) + '" data-action="finish" data-key="' + h(p.key) + '" data-finish="' + h(f.id) + '"' +
        ' data-focus="finish-' + h(p.key) + "-" + h(f.id) + '"></button>';
    }).join("");
    var qty = Number(p.quantity) || 1;
    var html = '<article class="card part-card' + (p.error ? " has-error" : "") + '" aria-label="' + h(p.name) + '">' +
      '<div class="part-head"><span class="part-icon">' + icon("cube", 18) + "</span>" +
      '<div class="part-title"><p class="part-name" title="' + h(p.name) + '">' + h(p.name) + '</p><p class="part-dims">' + h(p.dims) + "</p></div>" +
      '<button class="icon-btn" data-action="remove" data-key="' + h(p.key) + '" aria-label="Remove ' + h(p.name) + '" title="Remove" data-focus="remove-' + h(p.key) + '">' + icon("x", 14) + "</button></div>" +
      '<div class="part-controls"><div class="field field-grow"><span class="field-label" id="mat-' + h(p.key) + '">Material</span>' +
      '<div class="picker"><button class="picker-btn" aria-haspopup="listbox" aria-expanded="' + open + '" aria-labelledby="mat-' + h(p.key) + '"' +
      ' data-action="menu" data-key="' + h(p.key) + '" data-focus="menu-' + h(p.key) + '">' +
      '<span class="picker-name">' + h(m.short || m.name) + '</span><span class="chip' + (m.process === "sls" ? " is-sls" : "") + '">' + h(m.process_label) + "</span>" +
      '<span class="caret">' + icon("caret", 14) + "</span></button>" + (open ? materialMenu(p) : "") + "</div></div>" +
      '<div class="field"><span class="field-label" id="qty-' + h(p.key) + '">Quantity</span><div class="stepper" role="group" aria-labelledby="qty-' + h(p.key) + '">' +
      '<button data-action="qty" data-key="' + h(p.key) + '" data-delta="-1" aria-label="Fewer" data-focus="qm-' + h(p.key) + '"' + (qty <= 1 ? " disabled" : "") + ">&minus;</button>" +
      '<input type="number" min="1" max="' + h(state.max_quantity) + '" value="' + qty + '" data-qty="' + h(p.key) + '" aria-label="Quantity of ' + h(p.name) + '" data-focus="qty-' + h(p.key) + '">' +
      '<button data-action="qty" data-key="' + h(p.key) + '" data-delta="1" aria-label="More" data-focus="qp-' + h(p.key) + '"' + (qty >= state.max_quantity ? " disabled" : "") + ">+</button></div></div></div>" +
      '<div class="swatch-row"><span class="field-label">' + (m.process === "sls" ? "Finish" : "Color") + "</span>" +
      '<div class="swatches" role="radiogroup" aria-label="' + (m.process === "sls" ? "Finish" : "Color") + '">' + swatches + "</div>" +
      '<span class="swatch-name">' + h(finishName) + "</span></div>";
    if (p.error) {
      html += '<div class="part-error" role="alert">' + h(p.error);
      if (p.units_choices && p.units_choices.length) {
        html += '<div class="seg" role="group" aria-label="File units">' + p.units_choices.map(function (u) {
          return '<button data-action="units" data-key="' + h(p.key) + '" data-units="' + h(u) + '" aria-pressed="' + (p.units === u) + '">' + (u === "mm" ? "Millimeters" : "Inches") + "</button>";
        }).join("") + "</div>";
      }
      html += "</div>";
    }
    return html + "</article>";
  }

  function materialMenu(p) {
    var html = '<div class="menu" role="listbox" aria-label="Material">';
    (state.groups || []).forEach(function (g) {
      html += '<div class="menu-group" role="presentation">' + h(g.label) + "</div>";
      g.materials.forEach(function (id) {
        var m = materialById(id);
        var sel = id === p.material;
        html += '<button class="menu-item' + (sel ? " is-selected" : "") + '" role="option" aria-selected="' + sel + '"' +
          ' data-action="material" data-key="' + h(p.key) + '" data-material="' + h(id) + '">' +
          '<span class="menu-check">' + (sel ? icon("check", 14) : "") + "</span>" +
          '<span class="menu-text"><span class="menu-name">' + h(m.name) + '</span><span class="menu-desc">' + h(m.description) + "</span></span></button>";
      });
    });
    return html + "</div>";
  }

  SCREENS.working = function () {
    var p = state.progress || { text: "", phases: [] };
    var body;
    var actions;
    if (state.question && state.question.kind === "stl") {
      body = '<section class="card question" aria-labelledby="q-title">' + notice("warn", "Fusion couldn't export these parts as STEP: " + state.question.names.join(", ") + ".") +
        '<h2 id="q-title">Send them as STL instead?</h2>' +
        "<p>The add-in exports a high-resolution mesh in millimeters. The units check still compares each quoted size with the part in Fusion.</p></section>";
      actions = '<button class="btn btn-primary btn-lg" data-action="stl_yes" data-focus="stl-yes">Send as STL</button>' +
        '<div class="row"><button class="btn" data-action="stl_no" data-focus="stl-no">Cancel</button></div>';
      return { body: body, actions: actions };
    }
    body = '<section class="card working" aria-labelledby="w-title"><div class="spinner" aria-hidden="true"></div>' +
      '<h2 id="w-title">Getting your instant quote</h2>' +
      '<p class="status" id="status" role="status" aria-live="polite">' + h(p.text) + "</p>";
    if (p.phases && p.phases.length) {
      body += '<ol class="phases" id="phases-' + h(p.phase) + '">' + p.phases.map(function (ph) {
        return '<li class="is-' + h(ph.state) + '"><span class="phase-dot">' + (ph.state === "done" ? icon("check", 11) : "") + "</span>" + h(ph.label) +
          (ph.state === "active" ? '<span class="sr-only"> (in progress)</span>' : "") + "</li>";
      }).join("") + "</ol>";
    }
    body += '<p class="fine">Usually 10 to 30 seconds.</p></section>';
    actions = '<button class="btn btn-lg" data-action="cancel" data-focus="cancel">Cancel</button>';
    return { body: body, actions: actions };
  };

  function quoteCard(c) {
    var counts = { ok: 0, warn: 0, fail: 0 };
    (c.checks || []).forEach(function (r) { counts[r.state] = (counts[r.state] || 0) + 1; });
    var tally = counts.ok + " passed" + (counts.warn ? " &middot; " + counts.warn + " warning" + (counts.warn > 1 ? "s" : "") : "") +
      (counts.fail ? " &middot; " + counts.fail + " failed" : "");
    var html = '<article class="card" aria-label="' + h(c.name) + '"><div class="q-head">' +
      '<span class="part-icon">' + icon("cube", 18) + "</span>" +
      '<div class="part-title"><p class="part-name" title="' + h(c.name) + '">' + h(c.name) + '</p><p class="part-dims">' + h(c.dims) + "</p>" +
      '<div class="q-spec"><span class="dot" style="background:' + safeColor(c.finish_hex) + '"></span><span class="txt">' + h(c.material) + " &middot; " + h(c.finish_name) + "</span></div></div>" +
      '<div class="q-price"><span class="q-total">' + h(c.line_total) + '</span><span class="q-unit">' + h(c.unit_price) + " &times; " + h(c.quantity) + "</span></div></div>" +
      '<ul class="checks" aria-label="Printability checks"><li class="checks-title" aria-hidden="true"><span>Printability checks</span><span class="tally">' + tally + "</span></li>";
    (c.checks || []).forEach(function (r) {
      var ic = r.state === "ok" ? icon("check", 11) : (r.state === "warn" ? icon("warn", 16) : icon("x", 10));
      var label = r.state === "ok" ? "Passed: " : (r.state === "warn" ? "Warning: " : "Failed: ");
      html += '<li class="check is-' + h(r.state) + '"><span class="check-icon">' + ic + '</span><span><span class="sr-only">' + label + "</span>" + h(r.text) +
        (r.detail ? '<span class="check-detail">' + h(r.detail) + "</span>" : "") + "</span></li>";
    });
    return html + "</ul></article>";
  }

  function promoBanner() {
    if (!state.promo) { return ""; }
    return '<div class="promo">' + icon("tag", 18) + '<span class="promo-text">' + h(state.promo.text) + ' <span class="promo-code">' + h(state.promo.code) + "</span></span>" +
      '<button class="btn btn-sm" data-action="copy" data-code="' + h(state.promo.code) + '" data-focus="copy">' + (ui.copied ? "Copied" : "Copy") + "</button></div>";
  }

  function deleteBlock() {
    if (!state.uploaded_count) { return ""; }
    var n = state.uploaded_count;
    if (ui.confirmDelete) {
      return '<div class="card confirm" role="alertdialog" aria-labelledby="del-title"><p id="del-title"><b>Delete the ' + n + " file" + (n > 1 ? "s" : "") + " you uploaded?</b> " +
        "The current quote can't be ordered afterwards. Files on an order you placed are kept with the order.</p>" +
        '<div class="row"><button class="btn btn-sm btn-danger" data-action="delete_yes" data-focus="del-yes"' + (state.can_delete ? "" : " disabled") + ">" + icon("trash", 13) + "Delete files</button>" +
        '<button class="btn btn-sm" data-action="delete_no" data-focus="del-no">Keep them</button></div></div>';
    }
    return '<button class="linkbtn is-quiet" data-action="delete_ask" data-focus="del-ask"' + (state.can_delete ? "" : " disabled") + ">" + icon("trash", 13) + "Delete my uploaded files</button>";
  }

  SCREENS.quote = function () {
    var q = state.quote;
    if (!q) { return SCREENS.parts(); }
    var body = "";
    if (q.notice) { body += notice(q.notice.kind, q.notice.text); }
    body += '<div class="section-head"><h2 class="section-title">Your quote<span class="count">' + q.cards.length + " part" + (q.cards.length > 1 ? "s" : "") + "</span></h2>" +
      "</div>";
    q.cards.forEach(function (c) { body += quoteCard(c); });
    var s = q.summary;
    if (s) {
      body += '<section class="card summary" aria-label="Summary">' +
        '<div class="line"><span>' + h(s.parts_label) + '</span><span class="v">' + h(s.parts) + "</span></div>" +
        (s.discount ? '<div class="line"><span>Discount</span><span class="v">' + h(s.discount) + "</span></div>" : "") +
        (s.min_order ? '<div class="line"><span>Order minimum adjustment</span><span class="v">' + h(s.min_order) + "</span></div>" : "") +
        '<div class="line' + (s.free_shipping ? " is-free" : "") + '"><span>Shipping</span><span class="v">' + h(s.shipping) + "</span></div>" +
        '<div class="total"><span class="k">Total before tax</span><span class="v">' + h(s.total) + "</span></div>" +
        (s.ships_by || s.arrives_by ? '<div class="dates">' + icon("truck", 16) + "<span>Ships by <b>" + h(s.ships_by) + "</b> &middot; Arrives by <b>" + h(s.arrives_by) + "</b></span></div>" : "") +
        '<p class="tax">' + h(s.tax_note) + (s.valid_until ? ' &middot; <span class="nowrap">Prices valid until ' + h(s.valid_until) + "</span>" : "") + "</p></section>";
    }
    body += promoBanner();
    body += '<div class="more">' + (q.url ? link(q.url, icon("ext", 13) + "View quote on makepartsnow.com") : "") + deleteBlock() + "</div>";
    var total = s ? s.total : "";
    var actions = (q.can_order ? "" : '<p class="blocked" role="alert">' + h(q.order_blocked) + "</p>") +
      '<button class="btn btn-primary btn-lg" data-action="order" data-focus="order"' + (q.can_order ? "" : " disabled") + ">Order" +
      (total ? ' <span aria-hidden="true">&middot;</span> <span class="price">' + h(total) + "</span>" : "") + "</button>" +
      '<div class="row"><button class="btn" data-action="save" data-focus="save"' + (q.can_save ? "" : " disabled") + ">Save quote to design</button>" +
      '<button class="btn" data-action="edit" data-focus="edit">Edit parts</button></div>';
    return { body: body, actions: actions };
  };

  SCREENS.ordered = function () {
    var c = state.checkout || {};
    var body = '<section class="card state" aria-labelledby="o-title"><div class="state-icon is-ok">' + icon("check", 28) + "</div>" +
      '<h1 id="o-title">' + (c.opened ? "Checkout opened in your browser" : "Your checkout is ready") + "</h1>" +
      "<p>Finish your order on makepartsnow.com. You pay there through Stripe; the add-in never sees card details.</p>" +
      (c.url ? "<p>" + link(c.url, icon("ext", 13) + (c.opened ? " Open checkout again" : " Open checkout")) + "</p>" : "") +
      (c.valid_until ? '<p class="code">The checkout link works until ' + h(c.valid_until) + ".</p>" : "") + "</section>";
    body += promoBanner();
    var q = state.quote;
    if (q && q.summary) {
      body += '<section class="card summary"><div class="total" style="margin:0;padding:0;border:0"><span class="k">Total before tax</span><span class="v">' + h(q.summary.total) + "</span></div>" +
        '<div class="dates">' + icon("truck", 16) + "<span>Ships by <b>" + h(q.summary.ships_by) + "</b> &middot; Arrives by <b>" + h(q.summary.arrives_by) + "</b></span></div></section>";
    }
    body += '<div class="more">' + (q && q.url ? link(q.url, icon("ext", 13) + "View quote on makepartsnow.com") : "") + deleteBlock() + "</div>";
    var actions = '<button class="btn btn-lg" data-action="back_to_quote" data-focus="back-quote">Back to quote</button>' +
      '<div class="row"><button class="btn" data-action="save" data-focus="save"' + (q && q.can_save ? "" : " disabled") + ">Save quote to design</button>" +
      '<button class="btn" data-action="edit" data-focus="edit">New quote</button></div>';
    return { body: body, actions: actions };
  };

  SCREENS.error = function () {
    var e = state.error || { kind: "generic", title: "Something went wrong", message: "" };
    var look = {
      paused: ["pause", "is-warn"], offline: ["offline", "is-bad"], rate_limited: ["clock", "is-warn"],
      update: ["download", "is-warn"], generic: ["alert", "is-bad"]
    }[e.kind] || ["alert", "is-bad"];
    var body = '<section class="card state" role="alert" aria-labelledby="e-title"><div class="state-icon ' + look[1] + '">' + icon(look[0], 28) + "</div>" +
      '<h1 id="e-title">' + h(e.title) + "</h1><p>" + h(e.message) + "</p>" +
      (e.link ? "<p>" + link(e.link.url, icon("ext", 13) + " " + h(e.link.label)) + "</p>" : "") +
      (e.code && e.kind === "generic" ? '<p class="code">Code: ' + h(e.code) + "</p>" : "") + "</section>";
    var actions = '<button class="btn btn-primary btn-lg" data-action="retry" data-focus="retry">Try again</button>';
    if (e.kind !== "update") {
      actions += '<div class="row"><button class="btn" data-action="dismiss" data-focus="dismiss">Back to parts</button></div>';
    }
    return { body: body, actions: actions };
  };

  // -------------------------------------------------------------- toast

  function showToast(text, kind) {
    if (!text) { return; }
    toastEl.textContent = text;
    toastEl.className = "toast is-" + (kind || "info");
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.hidden = true; }, 7000);
  }
  toastEl.addEventListener("click", function () { toastEl.hidden = true; });

  // ------------------------------------------------------------- events

  function setQuantity(key, value) {
    var n = Math.round(Number(value));
    if (!isFinite(n) || n < 1) { n = 1; }
    if (state && n > state.max_quantity) { n = state.max_quantity; }
    send("set_part", { key: key, quantity: n });
  }

  function copyText(text) {
    var done = function () { ui.copied = true; render(false); setTimeout(function () { ui.copied = false; if (state) { render(false); } }, 2000); };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () { legacyCopy(text) && done(); });
        return;
      }
    } catch (e) { /* fall back */ }
    if (legacyCopy(text)) { done(); }
  }

  function legacyCopy(text) {
    var area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    document.body.removeChild(area);
    return ok;
  }

  document.addEventListener("click", function (ev) {
    var a = ev.target.closest ? ev.target.closest("a") : null;
    if (a) {
      // Never navigate the palette: Python opens allowed links in the system browser.
      ev.preventDefault();
      var url = a.getAttribute("data-link");
      if (url) { send("open_link", { url: url }); }
      return;
    }
    var el = ev.target.closest ? ev.target.closest("[data-action]") : null;
    if (!el) {
      if (ui.menu && !(ev.target.closest && ev.target.closest(".picker"))) { ui.menu = null; render(false); }
      return;
    }
    if (el.disabled) { return; }
    var key = el.getAttribute("data-key");
    switch (el.getAttribute("data-action")) {
      case "accept": send("accept_consent", { telemetry: !!(document.getElementById("telemetry") || {}).checked }); break;
      case "add_selected": send("add_selected", {}); break;
      case "remove": send("remove_part", { key: key }); break;
      case "menu":
        ui.menu = ui.menu === key ? null : key;
        if (ui.menu) {
          var current = null;
          (state.parts || []).forEach(function (p) { if (p.key === key) { current = p.material; } });
          ui.menuFocus = current;
        }
        render(false);
        break;
      case "material": ui.menu = null; send("set_part", { key: key, material: el.getAttribute("data-material") }); render(false); focusLater("menu-" + key); break;
      case "finish": send("set_part", { key: key, finish: el.getAttribute("data-finish") }); break;
      case "units": send("set_part", { key: key, units: el.getAttribute("data-units") }); break;
      case "qty":
        var input = document.querySelector('[data-qty="' + key + '"]');
        setQuantity(key, (Number(input && input.value) || 1) + Number(el.getAttribute("data-delta")));
        break;
      case "get_quote":
        var zip = document.getElementById("zip");
        send("get_quote", { zip: zip ? zip.value.trim() : (state.zip || "") });
        break;
      case "cancel": send("cancel", {}); break;
      case "stl_yes": send("stl_choice", { send: true }); break;
      case "stl_no": send("stl_choice", { send: false }); break;
      case "edit": send("edit_parts", {}); break;
      case "back_to_quote": send("back_to_quote", {}); break;
      case "order": send("order", {}); break;
      case "save": send("save_to_design", {}); break;
      case "copy": copyText(el.getAttribute("data-code") || ""); break;
      case "delete_ask": ui.confirmDelete = true; render(false); focusLater("del-no"); break;
      case "delete_no": ui.confirmDelete = false; render(false); focusLater("del-ask"); break;
      case "delete_yes": ui.confirmDelete = false; send("delete_files", {}); break;
      case "retry": send("retry", {}); break;
      case "dismiss": send("dismiss", {}); break;
    }
  });

  function focusLater(key) {
    var el = document.querySelector('[data-focus="' + key + '"]');
    if (el) { el.focus(); }
  }

  document.addEventListener("change", function (ev) {
    var key = ev.target.getAttribute && ev.target.getAttribute("data-qty");
    if (key) { setQuantity(key, ev.target.value); }
    if (ev.target.id === "zip") { send("set_zip", { zip: ev.target.value.trim() }); }
  });

  document.addEventListener("input", function (ev) {
    if (ev.target.id === "zip") {
      clearTimeout(zipTimer);
      var value = ev.target.value.trim();
      zipTimer = setTimeout(function () { send("set_zip", { zip: value }); }, 500);
    }
  });

  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape" && ui.menu) {
      var key = ui.menu;
      ui.menu = null;
      render(false);
      focusLater("menu-" + key);
      ev.preventDefault();
      return;
    }
    if (ev.key === "Enter") {
      if (ev.target.getAttribute && ev.target.getAttribute("data-qty")) { ev.target.blur(); return; }
      if (ev.target.id === "zip") { ev.preventDefault(); send("set_zip", { zip: ev.target.value.trim() }); return; }
    }
    if ((ev.key === "ArrowDown" || ev.key === "ArrowUp") && ui.menu) {
      var items = Array.prototype.slice.call(document.querySelectorAll(".menu .menu-item"));
      var i = items.indexOf(document.activeElement);
      var next = ev.key === "ArrowDown" ? Math.min(items.length - 1, i + 1) : Math.max(0, i - 1);
      if (items[next]) { items[next].focus(); }
      ev.preventDefault();
    }
  });

  // Development preview (mock.js) can hand in a state before Fusion would.
  window.MPN = { applyState: applyState, ui: ui, render: function () { if (state) { render(false); } } };

  waitForFusion();
})();
