/* Loads the development mock (palette/mock.js) only for index.html?mock=1.
   The packaged add-in has no mock.js, and Fusion never adds ?mock=1. */
(function () {
  "use strict";
  if (/[?&]mock=1(&|$)/.test(window.location.search)) {
    document.write('<script src="mock.js"><\/script>');
  }
})();
