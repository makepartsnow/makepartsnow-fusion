"""The add-in's names, ids and links, and ``HOST``: who it is to the core.

Links and limits that are the same for every add-in (privacy, terms, support,
the default material, part limits) are the core's (``core.host``). Every id
Fusion sees (commands, toolbar panel and controls, palette, custom event)
starts with ``MakePartsNow`` so it cannot collide with Fusion's own ids or
another add-in's.
"""

from __future__ import annotations

from .core.host import COMMON_EVENTS, Host

VERSION = "1.0.2"
ADDIN_NAME = "MakePartsNow"
DISPLAY_NAME = "MakePartsNow: Instant Quotes & 3D Printing Service"
COMMAND_NAME = "Get Instant Quote"
COMMAND_TOOLTIP = (
    "Open the Make Parts Now palette: instant prices for 3D printing your parts in SLS nylon "
    "or FDM plastics, then order them. No account needed."
)
SAVE_COMMAND_NAME = "Save Make Parts Now quote"
PALETTE_NAME = "Make Parts Now"
PALETTE_WIDTH = 380
PALETTE_HEIGHT = 760

# Fusion ids. All start with ADDIN_NAME.
COMMAND_ID = "MakePartsNow_QuoteCommand"  # the toolbar button; opens the palette
SAVE_COMMAND_ID = "MakePartsNowSaveQuote"  # hidden: writes the quote attributes as one undoable step
PALETTE_ID = "MakePartsNowPalette"
PANEL_ID = "MakePartsNowPanel"
PANEL_NAME = "MAKE PARTS NOW"
WORKER_EVENT_ID = "MakePartsNow_WorkerEvent"

# Where the button goes. Our own panel on the Design workspace's UTILITIES tab
# (tab id "ToolsTab"), promoted as a large button, plus the documented
# UTILITIES > ADD-INS panel. A missing workspace, tab or panel is skipped.
WORKSPACE_ID = "FusionSolidEnvironment"
TAB_ID = "ToolsTab"
PANEL_IDS = ("SolidScriptsAddinsPanel",)
# Our own toolbar panel, kept in the store build (owner, 15 Oct 2026). Autodesk's publisher guidelines
# say not to create a new panel; if review asks, set this to False: the button stays in UTILITIES > ADD-INS.
OWN_PANEL = True

# Public links (the shared ones are in core.host).
HELP_URL = "https://makepartsnow.com/fusion"  # live since 15 Oct 2026
REPO_URL = "https://github.com/makepartsnow/makepartsnow-fusion"

NOT_AFFILIATED = (
    "Make Parts Now is not affiliated with Autodesk. "
    "Autodesk and Fusion are trademarks of Autodesk, Inc."
)

# Consent text version. Raise it when the consent text changes materially, so
# every user sees and accepts the new text once.
CONSENT_VERSION = 2  # 2: the palette (0.2.0) also sends the material you choose

# The add-in's own words where the core's would differ (1.0.1's text, kept when it moved onto the core in 1.0.2).
WORDING = {
    "consent.sent_file": (
        "A STEP file of each part you add, named after the part (or STL, only if STEP export fails and you agree). "
        "Your name and company are removed from the STEP header first"
    ),
    "consent.when_quote": "Only when you click Get instant quote. Clicking parts in your design sends nothing.",
    "consent.when_open": "Opening the palette only fetches the current materials, limits and any promotion code.",
    "nothing_selected": "Nothing is selected. Click components or bodies in your design, then Add selected.",
    "save_failed_hint": "(a linked or read-only component can't be changed here).",
    "error.FILE_PARSE_FAILED": "The server could not read a part's geometry. Check that the body is a closed solid, then try again.",
    "part_error.FILE_PARSE_FAILED": "The file could not be read. Check that the body is a closed solid, then click {action}.",
}

HOST = Host(
    client_name="fusion",  # ?client=fusion; the usage-count client
    product="Fusion",  # User-Agent MakePartsNow-Fusion/<version>
    version=VERSION,
    program="Fusion",
    help_url=HELP_URL,
    repo_url=REPO_URL,
    settings_file="fusion-addin.json",  # %APPDATA%\MakePartsNow\fusion-addin.json
    base_url_env="MPN_FUSION_BASE_URL",
    consent_version=CONSENT_VERSION,
    not_affiliated=NOT_AFFILIATED,
    kind="add-in",
    quote_action="Get instant quote",
    select_hint="Click components or bodies in your design",
    events=COMMON_EVENTS | {"quote_saved_to_part"},
    wording=WORDING,
)
