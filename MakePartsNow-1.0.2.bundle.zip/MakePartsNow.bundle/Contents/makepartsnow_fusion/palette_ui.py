"""Everything the add-in adds to Fusion: buttons, a toolbar panel, the palette, events.

``start()`` (from the add-in's ``run``) only creates two command definitions,
the MAKE PARTS NOW panel on the UTILITIES tab with a promoted button, the same
button in UTILITIES > ADD-INS, and connects ``commandCreated``. No file, network
or heavy imports: the palette, the controller and the client load the first time
the button is clicked. ``stop()`` removes all of it: the palette, every control,
the panel, both command definitions, every handler and the custom event.

Commands:

* ``COMMAND_ID`` (the button) has no inputs, so Fusion shows no dialog and runs
  its execute handler, which creates (or shows) the palette, docked right.
* ``SAVE_COMMAND_ID`` is never on a toolbar. When the page asks to save the quote,
  ``FusionHost.request_save`` runs it with ``CommandDefinition.execute()``; its
  execute handler writes the attributes, so Fusion records the save as one
  undoable step ("everything you do in the execute event handler is bundled
  within a single transaction", Commands_UM).

Threading: every handler here runs on Fusion's main thread. Worker threads only
fire ``WORKER_EVENT_ID``; its handler routes job results to ``worker.Bridge``
and runs work the controller deferred (``FusionHost.defer``). Every handler
catches its own exceptions, so an add-in error never escapes into Fusion.
"""

from __future__ import annotations

import itertools
import json
import os
import threading
import time
import traceback
from typing import Any, Callable, Optional

import adsk.core

from .constants import (
    ADDIN_NAME,
    COMMAND_ID,
    COMMAND_NAME,
    COMMAND_TOOLTIP,
    PALETTE_HEIGHT,
    PALETTE_ID,
    PALETTE_NAME,
    PALETTE_WIDTH,
    OWN_PANEL,
    PANEL_ID,
    PANEL_IDS,
    PANEL_NAME,
    SAVE_COMMAND_ID,
    SAVE_COMMAND_NAME,
    TAB_ID,
    WORKER_EVENT_ID,
    WORKSPACE_ID,
)

ADDIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESOURCES = os.path.join(ADDIN_DIR, "resources")
PALETTE_HTML = os.path.join(ADDIN_DIR, "palette", "index.html")

_app: Optional[adsk.core.Application] = None
_ui: Optional[adsk.core.UserInterface] = None
_handlers: list[Any] = []  # commandCreated handlers: live for the add-in's lifetime
_command_handlers: list[Any] = []  # execute/destroy handlers of running commands
_runtime_handlers: list[Any] = []  # custom event and selection handlers, once the palette exists
_palette_handlers: list[tuple[Any, Any]] = []  # (event, handler) pairs on the current palette
_custom_event: Any = None
_bridge: Any = None
_controller: Any = None
_host: Any = None


# --------------------------------------------------------------------- guards


def report_error(context: str, details: str = "") -> None:
    """Show an unexpected error to the user. Never raises."""
    text = f"MakePartsNow: something went wrong while {context}.\n\n{details}".strip()
    try:
        if _ui is not None:
            _ui.messageBox(text, ADDIN_NAME)
    except Exception:  # noqa: BLE001 - nothing else can be done
        pass


def guarded(context: str, fn: Callable[[Any], None], args: Any) -> None:
    """Run a handler body, turning any exception into a message box."""
    try:
        fn(args)
    except Exception:  # noqa: BLE001 - an add-in error must never reach Fusion
        report_error(context, traceback.format_exc())


def _handler(base: type, context: str, fn: Callable[[Any], None]) -> Any:
    """An instance of a Fusion event handler class ``base`` whose notify runs ``fn`` guarded."""

    class _Handler(base):  # type: ignore[misc, valid-type]
        def __init__(self) -> None:
            super().__init__()

        def notify(self, args: Any) -> None:
            guarded(context, fn, args)

    return _Handler()


# ------------------------------------------------------------ start and stop


def start() -> None:
    """Create the commands and their buttons. Kept minimal: no file, network or heavy imports."""
    global _app, _ui
    _app = adsk.core.Application.get()
    _ui = _app.userInterface
    definitions = _ui.commandDefinitions
    for stale_id in (COMMAND_ID, SAVE_COMMAND_ID):
        stale = definitions.itemById(stale_id)
        if stale:
            stale.deleteMe()
    cmd_def = definitions.addButtonDefinition(COMMAND_ID, COMMAND_NAME, COMMAND_TOOLTIP, os.path.join(RESOURCES, "command"))
    created = _handler(adsk.core.CommandCreatedEventHandler, "opening Make Parts Now", _on_show_created)
    cmd_def.commandCreated.add(created)
    _handlers.append(created)
    save_def = definitions.addButtonDefinition(SAVE_COMMAND_ID, SAVE_COMMAND_NAME, "Save the Make Parts Now quote to the quoted parts.", "")
    save_created = _handler(adsk.core.CommandCreatedEventHandler, "saving the quote", _on_save_created)
    save_def.commandCreated.add(save_created)
    _handlers.append(save_created)
    if OWN_PANEL:
        _add_own_panel(cmd_def)
    for panel_id in PANEL_IDS:
        panel = _ui.allToolbarPanels.itemById(panel_id)
        if panel is None:
            continue
        old = panel.controls.itemById(COMMAND_ID)
        if old:
            old.deleteMe()
        panel.controls.addCommand(cmd_def)


def _panel_list() -> Any:
    """Where our panel goes: the UTILITIES tab ("ToolsTab") of the Design workspace, or, if
    that tab id is missing, the workspace's panels (Fusion then adds it to its Tools tab)."""
    assert _ui is not None
    workspace = _ui.workspaces.itemById(WORKSPACE_ID)
    if workspace is None:
        return None
    tab = workspace.toolbarTabs.itemById(TAB_ID)
    return tab.toolbarPanels if tab is not None else workspace.toolbarPanels


def _add_own_panel(cmd_def: Any) -> None:
    assert _ui is not None
    stale = _ui.allToolbarPanels.itemById(PANEL_ID)
    if stale:
        stale.deleteMe()
    panels = _panel_list()
    if panels is None:
        return
    panel = panels.add(PANEL_ID, PANEL_NAME, "", False)
    if panel is None:
        return
    control = panel.controls.addCommand(cmd_def)
    control.isPromoted = True
    control.isPromotedByDefault = True


def stop() -> None:
    """Remove everything start() and the palette added. Each step runs even if another fails."""
    global _custom_event, _bridge, _controller, _host
    steps: list[Callable[[], None]] = []
    if _controller is not None:
        steps.append(_controller.shutdown)
    elif _bridge is not None:
        steps.append(_bridge.cancel_all)
    if _ui is not None:
        ui = _ui

        def _remove_palette() -> None:
            # Each handler comes off only the event it was added to, each in its own try, and the palette is
            # always deleted: in 1.0.0 a failed removal skipped deleteMe(), and after a stop and run in the same
            # Fusion session the old palette came back with no handlers (owner's Windows test, 17 Oct 2026).
            for event, handler in _palette_handlers:
                try:
                    event.remove(handler)
                except Exception:  # noqa: BLE001 - keep cleaning up
                    pass
            palette = ui.palettes.itemById(PALETTE_ID)
            if palette:
                palette.deleteMe()

        def _remove_selection_handler() -> None:
            for handler in _runtime_handlers:
                if isinstance(handler, adsk.core.ActiveSelectionEventHandler):
                    ui.activeSelectionChanged.remove(handler)

        steps.extend([_remove_palette, _remove_selection_handler])
    if _custom_event is not None and _app is not None:
        event, app = _custom_event, _app

        def _unregister() -> None:
            for handler in [h for h in _runtime_handlers if isinstance(h, adsk.core.CustomEventHandler)]:
                event.remove(handler)
            app.unregisterCustomEvent(WORKER_EVENT_ID)

        steps.append(_unregister)
    if _ui is not None:
        ui = _ui

        def _remove_controls() -> None:
            for panel_id in PANEL_IDS:
                panel = ui.allToolbarPanels.itemById(panel_id)
                control = panel.controls.itemById(COMMAND_ID) if panel else None
                if control:
                    control.deleteMe()

        def _remove_panel() -> None:
            panel = ui.allToolbarPanels.itemById(PANEL_ID)
            if panel:
                control = panel.controls.itemById(COMMAND_ID)
                if control:
                    control.deleteMe()
                panel.deleteMe()

        def _remove_definitions() -> None:
            for cmd_id in (COMMAND_ID, SAVE_COMMAND_ID):
                cmd_def = ui.commandDefinitions.itemById(cmd_id)
                if cmd_def:
                    for handler in _handlers:
                        cmd_def.commandCreated.remove(handler)
                    cmd_def.deleteMe()

        steps.extend([_remove_controls, _remove_panel, _remove_definitions])
    for step in steps:
        try:
            step()
        except Exception:  # noqa: BLE001 - keep cleaning up
            pass
    for handlers in (_handlers, _command_handlers, _runtime_handlers, _palette_handlers):
        handlers.clear()
    _custom_event = None
    _bridge = None
    _controller = None
    _host = None


# ------------------------------------------------------------------ the host


class FusionHost:
    """What the controller needs from Fusion (see controller.py)."""

    def __init__(self, app: Any, ui: Any) -> None:
        self.app = app
        self.ui = ui
        self._ids = itertools.count(1)
        self._deferred: dict[int, Callable[[], None]] = {}
        self._queued_at: dict[int, float] = {}

    def palette(self) -> Any:
        # Looked up each time: Fusion deletes palettes when the user switches workspace.
        return self.ui.palettes.itemById(PALETTE_ID)

    def send(self, action: str, data: str) -> None:
        palette = self.palette()
        if palette is not None:
            palette.sendInfoToHTML(action, data)

    def selected_entities(self) -> list[Any]:
        selections = self.ui.activeSelections
        return [selections.item(i).entity for i in range(selections.count)]

    def design(self) -> Any:
        import adsk.fusion

        return adsk.fusion.Design.cast(self.app.activeProduct)

    def open_url(self, url: str) -> bool:
        """Open the system browser. Safe from a worker thread: it never calls Fusion."""
        import webbrowser

        return bool(webbrowser.open(url))

    def request_save(self) -> None:
        cmd_def = self.ui.commandDefinitions.itemById(SAVE_COMMAND_ID)
        if cmd_def is not None:
            cmd_def.execute()

    def defer(self, fn: Callable[[], None]) -> None:
        """Run ``fn`` on the main thread when Fusion is next idle (through the custom event).

        The event is fired from a short-lived thread, Autodesk's documented pattern: in 0.2.0 it was fired on the
        main thread, from inside this same event's handler, and Fusion never delivered it, so a quote stopped after
        exporting its first part (owner's test, 15 Oct 2026). If the event is refused or never arrives, the page's
        next check-in runs ``fn`` (``run_overdue``); it is never silently dropped.
        """
        tick = next(self._ids)
        self._deferred[tick] = fn
        self._queued_at[tick] = time.monotonic()
        payload = json.dumps({"kind": "tick", "id": tick})

        def fire() -> None:
            try:
                fired = self.app.fireCustomEvent(WORKER_EVENT_ID, payload)
            except Exception:  # noqa: BLE001 - Fusion closing, or the event unregistered
                fired = False
            if not fired:
                self._queued_at[tick] = 0.0  # overdue at once: the next main-thread event runs it

        try:
            threading.Thread(target=fire, name="MakePartsNow-tick", daemon=True).start()
        except RuntimeError:
            self._deferred.pop(tick, None)
            self._queued_at.pop(tick, None)
            fn()

    def run_deferred(self, tick: Any) -> None:
        fn = self._deferred.pop(tick, None) if isinstance(tick, int) else None
        self._queued_at.pop(tick, None)
        if fn is not None:
            fn()

    def run_overdue(self, after_s: float = 1.5) -> None:
        """On the main thread (any palette message, including the page's 2 s check-in while quoting): run deferred
        work whose custom event is overdue, refused or never delivered, so a quote can't stall on a lost event."""
        now = time.monotonic()
        for tick in sorted(t for t, at in self._queued_at.items() if now - at >= after_s):
            fn = self._deferred.pop(tick, None)
            self._queued_at.pop(tick, None)
            if fn is not None:
                fn()


# --------------------------------------------------------------- the palette


def _ensure_runtime() -> None:
    """Custom event, bridge, controller and the selection handler (once, on first click)."""
    global _custom_event, _bridge, _controller, _host
    if _controller is not None:
        return
    from .controller import PaletteController
    from .core.worker import Bridge

    assert _app is not None and _ui is not None
    event = _app.registerCustomEvent(WORKER_EVENT_ID)
    if event is None:  # left over from a crashed session
        _app.unregisterCustomEvent(WORKER_EVENT_ID)
        event = _app.registerCustomEvent(WORKER_EVENT_ID)
    handler = _handler(adsk.core.CustomEventHandler, "showing a result", _on_worker_event)
    event.add(handler)
    _runtime_handlers.append(handler)
    _custom_event = event
    _bridge = Bridge(WORKER_EVENT_ID, _app.fireCustomEvent)
    _host = FusionHost(_app, _ui)
    _controller = PaletteController(_host, _bridge)
    selection_handler = _handler(adsk.core.ActiveSelectionEventHandler, "reading your selection", _on_selection_changed)
    _ui.activeSelectionChanged.add(selection_handler)
    _runtime_handlers.append(selection_handler)


def show_palette() -> Any:
    """Create the palette (docked right) or show it again."""
    _ensure_runtime()
    assert _ui is not None
    url = PALETTE_HTML.replace("\\", "/")
    palette = _ui.palettes.itemById(PALETTE_ID)
    stale = palette is not None and not _palette_handlers
    if stale:
        # Left over from an earlier run in this Fusion session (1.0.0's stop could leave it): no click on it
        # reaches this run's Python, so it is replaced. If Fusion won't delete it, it gets handlers and a reload.
        try:
            palette.deleteMe()
        except Exception:  # noqa: BLE001 - handled below
            pass
        palette = _ui.palettes.itemById(PALETTE_ID)
    if palette is None:
        _palette_handlers.clear()
        palettes = _ui.palettes
        if hasattr(palettes, "add2"):
            palette = palettes.add2(PALETTE_ID, PALETTE_NAME, url, True, True, True, PALETTE_WIDTH, PALETTE_HEIGHT)
        else:
            palette = palettes.add(PALETTE_ID, PALETTE_NAME, url, True, True, True, PALETTE_WIDTH, PALETTE_HEIGHT, True)
        palette.dockingOption = adsk.core.PaletteDockingOptions.PaletteDockOptionsToVerticalOnly
        palette.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateRight
        try:
            palette.setMinimumSize(300, 480)
        except Exception:  # noqa: BLE001 - cosmetic
            pass
        _attach_palette_handlers(palette)
    elif stale:
        _attach_palette_handlers(palette)
        palette.htmlFileURL = url  # reloads the page, which then sends "ready"
        palette.isVisible = True
    else:
        palette.isVisible = True
        if _controller is not None:
            _controller.push()
    return palette


def _attach_palette_handlers(palette: Any) -> None:
    for event, base, context, fn in (
        (palette.incomingFromHTML, adsk.core.HTMLEventHandler, "handling the palette", _on_html),
        (palette.navigatingURL, adsk.core.NavigationEventHandler, "opening a link", _on_navigating),
        (palette.closed, adsk.core.UserInterfaceGeneralEventHandler, "closing the palette", _on_closed),
    ):
        handler = _handler(base, context, fn)
        event.add(handler)
        _palette_handlers.append((event, handler))


def _on_html(args: Any) -> None:
    html = adsk.core.HTMLEventArgs.cast(args)
    if _controller is None or html is None:
        return
    if _host is not None:
        _host.run_overdue()  # main thread: a step whose idle event is overdue runs now
    html.returnData = _controller.handle(html.action, html.data)


def _on_navigating(args: Any) -> None:
    """A link that would navigate the palette opens in the system browser instead."""
    nav = adsk.core.NavigationEventArgs.cast(args)
    if nav is not None and str(nav.navigationURL).startswith(("http://", "https://")):
        nav.launchExternally = True


def _on_closed(_args: Any) -> None:
    if _controller is not None:
        _controller.send_counts()


def _on_selection_changed(args: Any) -> None:
    if _controller is None or _ui is None:
        return
    palette = _ui.palettes.itemById(PALETTE_ID)
    if palette is None or not palette.isVisible:
        return
    event = adsk.core.ActiveSelectionEventArgs.cast(args)
    current = list(event.currentSelection) if event is not None else []
    _controller.on_selection_changed([s.entity for s in current])


def _on_worker_event(args: Any) -> None:
    info = adsk.core.CustomEventArgs.cast(args).additionalInfo
    try:
        message = json.loads(info)
    except (TypeError, ValueError):
        return
    if isinstance(message, dict) and message.get("kind") == "tick":
        if _host is not None:
            _host.run_deferred(message.get("id"))
        return
    if _bridge is not None:
        _bridge.dispatch(info)


# ------------------------------------------------------------------ commands


def _connect(event: Any, base: type, context: str, fn: Callable[[Any], None]) -> None:
    handler = _handler(base, context, fn)
    event.add(handler)
    _command_handlers.append(handler)


def _on_show_created(args: Any) -> None:
    command = adsk.core.CommandCreatedEventArgs.cast(args).command
    command.isRepeatable = False
    _connect(command.execute, adsk.core.CommandEventHandler, "opening Make Parts Now", lambda _a: show_palette())
    _connect(command.destroy, adsk.core.CommandEventHandler, "opening Make Parts Now", _on_command_destroy)


def _on_save_created(args: Any) -> None:
    command = adsk.core.CommandCreatedEventArgs.cast(args).command
    command.isRepeatable = False
    _connect(command.execute, adsk.core.CommandEventHandler, "saving the quote to your parts", _on_save_execute)
    _connect(command.destroy, adsk.core.CommandEventHandler, "saving the quote to your parts", _on_command_destroy)


def _on_save_execute(_args: Any) -> None:
    if _controller is not None:
        _controller.save_to_design()


def _on_command_destroy(_args: Any) -> None:
    _command_handlers.clear()
