"""The "Save quote to design" action: store the quote on a component as a Fusion attribute.

This runs only when the user asks for it, from the hidden save command's execute
event (``palette_ui``), so the change is one undoable step. The attribute's value
is the core's ``memory.build_payload``: the price, quantity, material, finish,
date and the quote link, never the delete token. The design is then modified,
and anyone the design is shared with can read the quote link, which the user is
told every time.
"""

from __future__ import annotations

import json
from typing import Any, Optional

from .core.memory import ATTR_GROUP, ATTR_NAME


def save(component: Any, payload: str) -> bool:
    """Write the attribute on the component (updates an existing one). Main thread only."""
    attribute = component.attributes.add(ATTR_GROUP, ATTR_NAME, payload)
    return attribute is not None


def load(component: Any) -> Optional[dict[str, Any]]:
    """Read a saved quote from the component, or None."""
    attribute = component.attributes.itemByName(ATTR_GROUP, ATTR_NAME)
    if attribute is None:
        return None
    try:
        data = json.loads(attribute.value)
    except (TypeError, ValueError):
        return None
    return data if isinstance(data, dict) else None
