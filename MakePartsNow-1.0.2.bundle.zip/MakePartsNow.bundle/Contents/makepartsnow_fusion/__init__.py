"""MakePartsNow add-in package for Autodesk Fusion.

Everything lives under this uniquely named package and is imported with
package-relative imports only, so nothing clashes with other add-ins in
Fusion's shared Python interpreter.

``core/`` is a vendored, pinned copy of the Make Parts Now CAD core (the
``/mcp/cad`` client, background jobs, flows, settings, consent text, the view
model and the panel's controller). It is never edited here: change it in
``makepartsnow-cad-core`` and sync it with that repo's ``scripts/sync-core.py``;
``CORE_PIN.json`` records the commit. The modules beside it are Fusion's
adapter: ``palette_ui`` (buttons, palette, events), ``controller`` (the palette's
messages onto the core's controller), ``palette_bridge`` (the message protocol),
``selection``, ``export`` and ``memory`` (the Fusion API) and ``constants``.
"""
