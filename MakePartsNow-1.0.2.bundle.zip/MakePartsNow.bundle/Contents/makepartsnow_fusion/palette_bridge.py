"""Messages between the palette's page and Python, checked on the way in.

The page calls ``adsk.fusionSendData(action, json)``; Fusion hands that to the
palette's ``incomingFromHTML`` handler as ``HTMLEventArgs.action`` and ``.data``.
``parse`` turns it into an ``Incoming`` or None: unknown actions, data that
isn't a JSON object and fields of the wrong type are dropped, never raised, so a
broken or hostile page can't make the add-in do anything it doesn't offer.

Python answers with ``palette.sendInfoToHTML(action, json)``. ``encode`` builds
those: ``state`` (the whole view model; the page draws only from it),
``progress`` (one line of text while a job runs) and ``toast`` (a short notice).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Optional

KEY_RE = re.compile(r"^[A-Za-z0-9:._\-]{1,200}$")
ID_RE = re.compile(r"^[a-z0-9_\-]{1,40}$")

OUTGOING = frozenset({"state", "progress", "toast"})


@dataclass(frozen=True)
class Incoming:
    action: str
    data: dict[str, Any] = field(default_factory=dict)


def _none(_data: Mapping[str, Any]) -> dict[str, Any]:
    return {}


def _bool(name: str, required: bool = True) -> Callable[[Mapping[str, Any]], Optional[dict[str, Any]]]:
    def check(data: Mapping[str, Any]) -> Optional[dict[str, Any]]:
        value = data.get(name)
        if value is None and not required:
            return {name: False}
        return {name: value} if isinstance(value, bool) else None

    return check


def _key(data: Mapping[str, Any]) -> Optional[dict[str, Any]]:
    value = data.get("key")
    return {"key": value} if isinstance(value, str) and KEY_RE.match(value) else None


def _set_part(data: Mapping[str, Any]) -> Optional[dict[str, Any]]:
    out = _key(data)
    if out is None:
        return None
    if "quantity" in data:
        quantity = data["quantity"]
        if isinstance(quantity, bool) or not isinstance(quantity, (int, float)) or quantity != int(quantity):
            return None
        out["quantity"] = int(quantity)
    for name in ("material", "finish"):
        if name in data:
            value = data[name]
            if not isinstance(value, str) or not ID_RE.match(value):
                return None
            out[name] = value
    if "units" in data:
        if data["units"] not in ("mm", "in"):
            return None
        out["units"] = data["units"]
    return out if len(out) > 1 else None


def _zip(data: Mapping[str, Any]) -> Optional[dict[str, Any]]:
    value = data.get("zip", "")
    if not isinstance(value, str) or len(value) > 20:
        return None
    return {"zip": value}


def _url(data: Mapping[str, Any]) -> Optional[dict[str, Any]]:
    value = data.get("url")
    if not isinstance(value, str) or len(value) > 2000:
        return None
    return {"url": value}


# action -> validator returning the clean data, or None to drop the message.
INCOMING: dict[str, Callable[[Mapping[str, Any]], Optional[dict[str, Any]]]] = {
    "ready": _none,
    "ping": _none,
    "accept_consent": _bool("telemetry", required=False),
    "add_selected": _none,
    "remove_part": _key,
    "clear_parts": _none,
    "set_part": _set_part,
    "set_zip": _zip,
    "get_quote": _zip,
    "cancel": _none,
    "stl_choice": _bool("send"),
    "edit_parts": _none,
    "back_to_quote": _none,
    "order": _none,
    "save_to_design": _none,
    "delete_files": _none,
    "open_link": _url,
    "retry": _none,
    "dismiss": _none,
}


def parse(action: Any, data: Any) -> Optional[Incoming]:
    """Validate one message from the page. Returns None for anything not understood."""
    if not isinstance(action, str) or action not in INCOMING:
        return None
    if data is None or data == "":
        payload: Any = {}
    elif isinstance(data, str):
        try:
            payload = json.loads(data)
        except ValueError:
            return None
    else:
        payload = data
    if not isinstance(payload, Mapping):
        return None
    clean = INCOMING[action](payload)
    if clean is None:
        return None
    return Incoming(action, clean)


def encode(action: str, payload: Any) -> tuple[str, str]:
    """(action, JSON text) for ``sendInfoToHTML``."""
    if action not in OUTGOING:
        raise ValueError(f"unknown outgoing action {action}")
    return action, json.dumps(payload, separators=(",", ":"), ensure_ascii=False)

