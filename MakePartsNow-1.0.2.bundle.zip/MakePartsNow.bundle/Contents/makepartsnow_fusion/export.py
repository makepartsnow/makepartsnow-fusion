"""Write one part to STEP or STL with Fusion's export manager.

STEP comes first: it carries exact geometry and its units. Fusion documents the
STEP export geometry as a Component (``createSTEPExportOptions``) or an
Occurrence (``STEPExportOptions.geometry``), so the component is tried first and
the occurrence second. If both fail, the caller may offer STL, exported from the
solid body itself in millimeters (``STLExportOptions.unitType`` is set
explicitly; otherwise it follows the design's default units).

Export calls the Fusion API, so it runs on the main thread. The private temp
folder, the file names and the STEP header scrub are the core's
(``core.export``); ``export_part`` here is the exporter callback it calls.
"""

from __future__ import annotations

import os
from typing import Any

from .core.export import written

MM_DISTANCE_UNITS = 0  # adsk.fusion.DistanceUnits.MillimeterDistanceUnits
MESH_REFINEMENT_HIGH = 0  # adsk.fusion.MeshRefinementSettings.MeshRefinementHigh


def export_step(export_manager: Any, part: Any, path: str) -> bool:
    """Write the part's component (or, failing that, its occurrence) to STEP."""
    targets = [part.component]
    if part.occurrence is not None:
        targets.append(part.occurrence)
    for geometry in targets:
        try:
            options = export_manager.createSTEPExportOptions(path, geometry)
            if options is not None and export_manager.execute(options) and written(path):
                return True
        except Exception:  # noqa: BLE001 - try the next geometry, then report failure
            pass
        if os.path.exists(path):
            os.remove(path)
    return False


def export_stl(export_manager: Any, part: Any, path: str) -> bool:
    """Write the part's solid body to a binary STL in millimeters."""
    try:
        options = export_manager.createSTLExportOptions(part.body, path)
        if options is None:
            return False
        options.isBinaryFormat = True
        options.meshRefinement = MESH_REFINEMENT_HIGH
        options.unitType = MM_DISTANCE_UNITS
        options.sendToPrintUtility = False
        return bool(export_manager.execute(options)) and written(path)
    except Exception:  # noqa: BLE001 - reported to the user as an export failure
        return False


def export_part(export_manager: Any, part: Any, path: str, fmt: str) -> bool:
    """The core's exporter callback: write ``part`` to ``path`` as ``fmt`` ("step" or "stl")."""
    return export_step(export_manager, part, path) if fmt == "step" else export_stl(export_manager, part, path)
