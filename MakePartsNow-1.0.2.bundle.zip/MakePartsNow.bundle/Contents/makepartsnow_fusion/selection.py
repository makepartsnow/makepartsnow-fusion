"""Turn the user's selection into parts to quote, refusing anything that isn't one solid.

Rules (each refusal says what to change):

* 1 to 25 parts. A part is a component; selecting a component (occurrence), one
  of its bodies or a face of one of its bodies selects that component. The same component selected twice
  is one part (set its quantity instead).
* Each component has exactly one solid B-Rep body, hidden ones included. A
  component's STEP export leaves hidden bodies out (spike, Fusion 2705.1.30,
  15 Oct 2026), so this is stricter than the export needs: it keeps "one part,
  one body" unambiguous for the beta. Counting only visible solids is a possible
  relaxation; the units check would catch a body the export didn't carry.
* No surface bodies or mesh bodies alongside the solid, and no sub-components:
  a component's STEP export includes its child components (same spike), so a
  parent would be quoted as one part made of all its children's bodies.
* The root component counts only when it holds the one solid body and nothing
  else (no sub-components), because exporting the root exports the whole design.

Runs on the main thread (it reads the Fusion model). Duck-typed so tests can use
the fake ``adsk`` package.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Sequence

from .units import cm_box_to_mm_dims

OCCURRENCE_TYPE = "adsk::fusion::Occurrence"
BODY_TYPE = "adsk::fusion::BRepBody"
COMPONENT_TYPE = "adsk::fusion::Component"
FACE_TYPE = "adsk::fusion::BRepFace"
SUPPORTED_TYPES = frozenset({OCCURRENCE_TYPE, BODY_TYPE, COMPONENT_TYPE, FACE_TYPE})
NOT_A_PART = "Select components (in the browser or the canvas) or their bodies."


def is_supported(entity: Any) -> bool:
    """Whether ``entity`` can name a part (the palette ignores sketches, edges and the like when you click)."""
    return getattr(entity, "objectType", "") in SUPPORTED_TYPES


@dataclass
class PartRef:
    key: str
    name: str
    component: Any
    body: Any
    occurrence: Optional[Any]
    is_root: bool
    local_dims_mm: tuple[float, float, float]
    world_dims_mm: Optional[tuple[float, float, float]] = None

    @property
    def dims_candidates(self) -> list[tuple[float, float, float]]:
        return [d for d in (self.local_dims_mm, self.world_dims_mm) if d is not None]


@dataclass
class SelectionResult:
    parts: list[PartRef] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return bool(self.parts) and not self.errors


def _count(collection: Any) -> int:
    try:
        return int(collection.count)
    except (AttributeError, TypeError):
        return 0


def _plural(n: int, word: str) -> str:
    return f"{n} {word}" if n == 1 else f"{n} {word}s"


def _items(collection: Any) -> list[Any]:
    return [collection.item(i) for i in range(_count(collection))]


def box_dims_mm(entity: Any) -> tuple[float, float, float]:
    """Sorted extents in mm of a body's tight bounding box (falls back to the plain box)."""
    box = None
    try:
        box = entity.preciseBoundingBox
    except Exception:  # noqa: BLE001 - older Fusion builds or transient bodies
        box = None
    if box is None:
        box = entity.boundingBox
    lo, hi = box.minPoint, box.maxPoint
    return cm_box_to_mm_dims((lo.x, lo.y, lo.z), (hi.x, hi.y, hi.z))


def _native(entity: Any) -> Any:
    native = getattr(entity, "nativeObject", None)
    return native if native is not None else entity


def _component_key(component: Any) -> str:
    for attr in ("id", "entityToken", "name"):
        value = getattr(component, attr, None)
        if value:
            return f"{attr}:{value}"
    return f"obj:{id(component)}"


def resolve(entity: Any) -> tuple[Optional[Any], Optional[Any], str]:
    """(component, occurrence or None, error) for one selected entity."""
    kind = getattr(entity, "objectType", "")
    if kind == FACE_TYPE:
        entity = getattr(entity, "body", None)
        kind = getattr(entity, "objectType", "")
    if kind == OCCURRENCE_TYPE:
        return entity.component, entity, ""
    if kind == BODY_TYPE:
        occurrence = getattr(entity, "assemblyContext", None)
        component = _native(entity).parentComponent
        return component, occurrence, ""
    if kind == COMPONENT_TYPE:
        return entity, None, ""
    return None, None, NOT_A_PART


def check_component(component: Any, is_root: bool) -> tuple[Optional[Any], str]:
    """(the one solid body, error message) for a component."""
    name = getattr(component, "name", "This component")
    bodies = _items(component.bRepBodies)
    solids = [b for b in bodies if getattr(b, "isSolid", False)]
    surfaces = len(bodies) - len(solids)
    meshes = _count(getattr(component, "meshBodies", None))
    children = _count(component.occurrences)
    if children:
        if is_root:
            return None, (
                f'"{name}" is the top of the design and has {_plural(children, "component")} under it. '
                "Select the components to print instead."
            )
        return None, (
            f'"{name}" has {_plural(children, "sub-component")}. Select the sub-components themselves, '
            "or combine the part into one body in one component."
        )
    if not solids:
        return None, f'"{name}" has no solid body. Only closed solid bodies can be printed.'
    if len(solids) > 1:
        hidden = sum(1 for b in solids if not getattr(b, "isVisible", True))
        extra = f" ({hidden} of them hidden)" if hidden else ""
        return None, (
            f'"{name}" has {len(solids)} solid bodies{extra}. Each part must be exactly one solid body: '
            "combine them, or move the extra bodies to their own components."
        )
    if surfaces or meshes:
        return None, (
            f'"{name}" also has {surfaces + meshes} surface or mesh body(ies). Remove them or move them '
            "to another component, so only the solid body is sent."
        )
    return solids[0], ""


def collect(entities: Sequence[Any], root_component: Any, max_parts: int = 25) -> SelectionResult:
    """Validate the selected entities and return the parts with their local sizes."""
    result = SelectionResult()
    seen: set[str] = set()
    root_key = _component_key(root_component) if root_component is not None else None
    for entity in entities:
        component, occurrence, error = resolve(entity)
        if error:
            if error not in result.errors:
                result.errors.append(error)
            continue
        key = _component_key(component)
        if key in seen:
            continue
        seen.add(key)
        is_root = key == root_key
        body, error = check_component(component, is_root)
        if error:
            result.errors.append(error)
            continue
        local = box_dims_mm(body)
        world = None
        if occurrence is not None:
            try:
                world = box_dims_mm(body.createForAssemblyContext(occurrence))
            except Exception:  # noqa: BLE001 - world box is only a second opinion
                world = None
        result.parts.append(
            PartRef(
                key=key,
                name=str(getattr(component, "name", "Part")),
                component=component,
                body=body,
                occurrence=occurrence,
                is_root=is_root,
                local_dims_mm=local,
                world_dims_mm=world,
            )
        )
    if len(result.parts) > max_parts:
        result.errors.append(f"{len(result.parts)} parts are selected. Quote up to {max_parts} parts at a time.")
    return result
