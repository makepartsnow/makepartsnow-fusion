"""Fusion's lengths in mm.

Fusion's internal length unit is the centimeter, so a local bounding box is
converted with cm x 10 before the core's units check (``core.units``) compares
it with the size the server measured.
"""

from __future__ import annotations

from typing import Sequence


def cm_box_to_mm_dims(min_cm: Sequence[float], max_cm: Sequence[float]) -> tuple[float, float, float]:
    """Extents of a Fusion bounding box (cm corners) in mm, sorted smallest first."""
    dims = sorted(abs(float(b) - float(a)) * 10.0 for a, b in zip(min_cm, max_cm))
    return (dims[0], dims[1], dims[2])
