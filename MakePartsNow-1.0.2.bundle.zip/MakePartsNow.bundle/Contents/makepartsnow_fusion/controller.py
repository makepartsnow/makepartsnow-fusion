"""The palette's controller: the core's ``Controller`` behind the palette's message protocol.

The state machine (screens, the export queue, quotes, revise, checkout, delete,
stale quotes) is the core's (``core.controller.Controller``). This module is
Fusion's side of it:

* ``FusionCad`` is the core's ``cad`` adapter: Fusion's selection (``selection``),
  export (``export``), the palette (``sendInfoToHTML``) and saving the quote as a
  component attribute (``memory``).
* ``PaletteController`` takes the page's messages (``handle``, from the
  palette's ``incomingFromHTML``), checks them with ``palette_bridge.parse`` and
  calls the core's action methods. It also takes Fusion's selection event
  (``on_selection_changed``) and the hidden save command (``save_to_design``).

It talks to Fusion through a small ``host`` object (``palette_ui.FusionHost``),
so tests drive it without Fusion:

* ``host.send(action, json_text)``: ``palette.sendInfoToHTML``
* ``host.selected_entities()``: the entities in ``ui.activeSelections``
* ``host.design()``: the active design, or None
* ``host.open_url(url) -> bool``: the system browser
* ``host.request_save()``: run the hidden save command (which calls ``save_to_design``)
* ``host.defer(fn)``: call ``fn`` on the main thread once Fusion is idle (lets the
  page repaint between part exports)

Everything runs on Fusion's main thread; network work runs on worker threads
through ``bridge`` (``core.worker.Bridge``). Nothing is uploaded until the user
accepted the consent text and clicked Get instant quote.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from . import export, memory, selection
from .constants import HOST
from .core import controller as core_controller
from .core import settings as settings_mod
from .core.client import CadClient
from .core.controller import ORDERED, QUOTE
from .palette_bridge import Incoming, encode, parse

NO_DESIGN = "Open a design (the DESIGN workspace) to quote its parts."


def make_client(current: settings_mod.Settings) -> CadClient:
    return core_controller.make_client(HOST, current)


def load_settings() -> settings_mod.Settings:
    return settings_mod.load(HOST)


def save_settings(current: settings_mod.Settings) -> str:
    return settings_mod.save(current, HOST)


class FusionCad:
    """The core controller's ``cad`` adapter on top of the palette's ``host``."""

    def __init__(self, host: Any) -> None:
        self.host = host
        self.clicked: Optional[list[Any]] = None  # the entities of the selection event being handled

    def send(self, action: str, payload: Any) -> None:
        name, text = encode(action, payload)
        self.host.send(name, text)

    # -- the model

    def selected_parts(self, explicit: bool) -> tuple[list[Any], list[str]]:
        """The selected parts and the refusals. A plain click keeps only entities that can name a part, and gives
        the refusals of those (one with two bodies, say); sketches and edges are ignored without a word."""
        if self.clicked is not None:
            entities = list(self.clicked)
        else:
            try:
                entities = list(self.host.selected_entities())
            except Exception:  # noqa: BLE001 - no design, or the selection is in flux
                entities = []
        if not explicit:
            entities = [e for e in entities if selection.is_supported(e)]
        if not entities:
            return [], []
        design = self.host.design()
        if design is None:
            return [], [NO_DESIGN]
        result = selection.collect(entities, design.rootComponent, max_parts=10**6)
        return result.parts, list(result.errors)

    def export(self, part: Any, path: str, fmt: str) -> bool:
        design = self.host.design()
        if design is None:
            return False  # the design is no longer open
        return export.export_part(design.exportManager, part, path, fmt)

    def save_quote(self, part: Any, payload: str) -> bool:
        return memory.save(part.component, payload)

    # -- the palette

    def push(self, state: dict[str, Any]) -> None:
        self.send("state", state)

    def progress(self, progress: Any) -> None:
        self.send("progress", progress)

    def toast(self, text: str, kind: str) -> None:
        self.send("toast", {"text": text, "kind": kind})

    # -- the system

    def open_url(self, url: str) -> bool:
        return bool(self.host.open_url(url))

    def defer(self, fn: Callable[[], None]) -> None:
        self.host.defer(fn)


class PaletteController:
    """The page's messages and Fusion's events, onto the core's ``Controller``.

    Anything else (``push``, ``state``, ``send_counts``, ``shutdown``, the
    controller's fields) is the core controller's.
    """

    def __init__(
        self,
        host: Any,
        bridge: Any,
        *,
        load_settings: Callable[[], settings_mod.Settings] = load_settings,
        save_settings: Callable[[settings_mod.Settings], Any] = save_settings,
        client_factory: Optional[Callable[[settings_mod.Settings], CadClient]] = None,
    ) -> None:
        self.host = host
        self.cad = FusionCad(host)
        self.core = core_controller.Controller(
            HOST,
            self.cad,
            bridge,
            load_settings=load_settings,
            save_settings=save_settings,
            client_factory=client_factory or (lambda current: make_client(current)),
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self.core, name)

    def handle(self, action: Any, data: Any) -> str:
        """One message from the page. Returns the view model as JSON (the page's ``returnData``)."""
        message = parse(action, data)
        if message is not None:
            getattr(self, "on_" + message.action)(message)
        return encode("state", self.core.state())[1]

    # ------------------------------------------------------------ the page

    def on_ready(self, _msg: Incoming) -> None:
        self.core.ready()

    def on_ping(self, _msg: Incoming) -> None:
        """The page checks in every 2 s while a quote is running; handling any message first runs a stalled step."""

    def on_accept_consent(self, msg: Incoming) -> None:
        self.core.accept_consent(bool(msg.data.get("telemetry")))

    def on_add_selected(self, _msg: Incoming) -> None:
        self.core.add_selected()

    def on_remove_part(self, msg: Incoming) -> None:
        self.core.remove_part(msg.data["key"])

    def on_clear_parts(self, _msg: Incoming) -> None:
        self.core.clear_parts()

    def on_set_part(self, msg: Incoming) -> None:
        data = msg.data
        self.core.set_part(
            data["key"],
            quantity=data.get("quantity"),
            material=data.get("material"),
            finish=data.get("finish"),
            units=data.get("units"),
        )

    def on_set_zip(self, msg: Incoming) -> None:
        self.core.set_zip(msg.data["zip"])

    def on_get_quote(self, msg: Incoming) -> None:
        self.core.get_quote(msg.data.get("zip"))

    def on_cancel(self, _msg: Incoming) -> None:
        self.core.cancel()

    def on_stl_choice(self, msg: Incoming) -> None:
        self.core.stl_choice(msg.data["send"])

    def on_edit_parts(self, _msg: Incoming) -> None:
        self.core.edit_parts()

    def on_back_to_quote(self, _msg: Incoming) -> None:
        if self.core.screen == ORDERED:  # the page offers it only after checkout
            self.core.back_to_quote()

    def on_order(self, _msg: Incoming) -> None:
        self.core.order()

    def on_save_to_design(self, _msg: Incoming) -> None:
        core = self.core
        if core.screen not in (QUOTE, ORDERED) or core.quote is None:
            return
        blocked = core.order_blocked
        if blocked and not blocked.startswith("Wait"):
            core.toast("Nothing was saved: " + blocked, "error")
            return
        self.host.request_save()

    def on_delete_files(self, _msg: Incoming) -> None:
        self.core.delete_files()

    def on_open_link(self, msg: Incoming) -> None:
        self.core.open_link(msg.data["url"])

    def on_retry(self, _msg: Incoming) -> None:
        self.core.retry()

    def on_dismiss(self, _msg: Incoming) -> None:
        self.core.dismiss()

    # ---------------------------------------------------------- Fusion events

    def on_selection_changed(self, entities: list[Any]) -> None:
        """Fusion's activeSelectionChanged: clicking parts in the design adds them (parts screen only)."""
        self.cad.clicked = list(entities)
        try:
            self.core.on_selection_changed()
        finally:
            self.cad.clicked = None

    def save_to_design(self) -> tuple[int, list[str]]:
        """Write the quote to each quoted part's component. Called inside the hidden save
        command's execute handler, so Fusion records it as one undoable step."""
        return self.core.save_to_design()
